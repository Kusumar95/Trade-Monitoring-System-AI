
# Trade Monitoring System – AI+ (Demo Stream v2)

Adds:
- Buttons to ingest GOOD/BAD data for each agent in real time
- One-click demo data stream (start/stop) that continuously feeds dummy data
- Live charts + AI insights + incident report export
